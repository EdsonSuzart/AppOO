﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RedisPort
{
    public class Repository
    {
        private static List<MongoDB> _list = new List<MongoDB>(); 

        public List<MongoDB> GetProducts()
        {
            return _list;
        }

        public void AddToCache(MongoDB product) => _list.Add(product);

    }
}
