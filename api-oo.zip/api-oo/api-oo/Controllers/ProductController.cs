﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Adapter;
using Business.UseCase;
using Business.UseCase.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace apioo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IDiscount _discount;
        private readonly IProductService _productService;

        public ProductController()
        {
            _discount = new DiscountAdapter();
            _productService = new RedisAdapter(new ProductAdapter());

        }

        [Route("{id}")]
        public ActionResult<Product> Get(int id)
        {
            var product = _productService.GetProduct(id);

            product.CalculateDiscount(_discount.GetDiscount(id));

            return product;
        }
    }
}