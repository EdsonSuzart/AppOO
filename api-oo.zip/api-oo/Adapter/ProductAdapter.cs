﻿using Business.UseCase;
using Business.UseCase.Interface;
using MongoPort;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace Adapter
{
    public class ProductAdapter : IProductService
    {
        public Product GetProduct(int idProduct)
        {
            var product = new Repository().GetProducts().FirstOrDefault(w => w.IdProduct == idProduct);
            return Adapter(product);
        }

        private Product Adapter(MongoPort.MongoDB product) =>
            new Product
            {
                Id = product.IdProduct,
                Name = product.Name,
                Description = product.Description,
                Value = product.Value
            };
    }
}
