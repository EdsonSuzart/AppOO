﻿using Business.UseCase.Interface;
using SQLServerPort;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace Adapter
{
    public class DiscountAdapter : IDiscount
    {
        public decimal GetDiscount(int idProduct)
        {
            var product = new Repository().GetProducts().FirstOrDefault(f => f.IdProduct == idProduct);

            return product != null ? product.Discount : 0;
        }
    }
}
