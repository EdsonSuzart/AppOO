﻿using Business.UseCase.Interface;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Business.UseCase;

namespace Adapter
{
    public class RedisAdapter : IProductService
    {
        private readonly IProductService _productService;

        public RedisAdapter(IProductService productService)
        {
            _productService = productService;
        }

        public Product GetProduct(int idProduct)
        {
            var repository = new RedisPort.Repository();

            var productRedis = repository.GetProducts().FirstOrDefault(w => w.IdProduct == idProduct);

            if (productRedis == null)
            {
                var product = _productService.GetProduct(idProduct);

                repository.AddToCache(Adapter(product));

                return product;

            }

            return Adapter(productRedis);
        }

        private Product Adapter(RedisPort.MongoDB product) =>
            new Product
            {
                Id = product.IdProduct,
                Name = product.Name,
                Description = product.Description,
                Value = product.Value
            };

        private RedisPort.MongoDB Adapter( Product product) =>
            new RedisPort.MongoDB
            {
                IdProduct = product.Id,
                Name = product.Name,
                Description = product.Description,
                Value = product.Value
            };
    }
}
