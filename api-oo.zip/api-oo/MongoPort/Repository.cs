﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MongoPort
{
    public class Repository
    {
        public List<MongoDB> GetProducts()
        {
            return new List<MongoDB> { new MongoDB { IdProduct = 1, Name= "product 1", Description = "product description", Value = 100 },
                 new MongoDB { IdProduct = 2, Name= "product 1", Description = "product description", Value = 200 },
                  new MongoDB { IdProduct = 3, Name= "product 1", Description = "product description", Value = 300 },
                   new MongoDB { IdProduct = 4, Name= "product 1", Description = "product description", Value = 400 },
                    new MongoDB { IdProduct = 5, Name= "product 1", Description = "product description", Value = 500 },
            };
        }
    }
}
