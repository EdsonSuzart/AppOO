﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SQLServerPort
{
    public class Repository
    {
        public List<Product> GetProducts()
        {
            return new List<Product> { new Product { IdProduct = 1, Discount = 10 },
                new Product { IdProduct = 2, Discount = 10 },
                new Product { IdProduct = 3, Discount = 10 },
                new Product { IdProduct = 4, Discount = 2 },
                new Product { IdProduct = 5, Discount = 3 },
            };
        }
    }
}
