﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SQLServerPort
{
    public class Product
    {
        public int IdProduct { get; set; }
        public decimal Discount { get; set; }
    }
}
