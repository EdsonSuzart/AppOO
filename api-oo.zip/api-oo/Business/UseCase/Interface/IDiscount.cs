﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Business.UseCase.Interface
{
    public interface IDiscount
    {
        decimal GetDiscount(int idProduct);
    }
}
