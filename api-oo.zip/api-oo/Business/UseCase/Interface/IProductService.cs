﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Business.UseCase.Interface
{
    public interface IProductService
    {
        Product GetProduct(int idProduct);
    }
}
